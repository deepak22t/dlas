from fastapi import FastAPI
from fastapi import APIRouter
from pydantic import BaseModel
from contextlib import asynccontextmanager
from sqlalchemy import create_engine,text
from sqlalchemy.orm import sessionmaker,Session
from collections.abc import Generator



@asynccontextmanager
async def start(app:FastAPI):
    print("Hello")
    yield 
    print("Bolo")
    
app = FastAPI(debug=True,title='Testing',version='1.1.2', description="desciption is here!",lifespan=start)



chat_router= APIRouter()

class ChatRequest(BaseModel):
    input_text : str

class ChatResponse(BaseModel): 
    output_text : str

@chat_router.post('/chat')
def chat(req:ChatRequest)->ChatResponse:
    input_text =  req.input_text
    print("Human : {input_text}")
    output_text = "Working on it"
    return {
        'output_text' : output_text
    }


app.include_router(chat_router)

url = "abc"
##database setup
engine =  create_engine(url)
session = sessionmaker(
    bind=engine
)

db:Session = session



#check connection
with engine.connect as conn:
    conn.execute(text("Select 1"))
    print("connected")
    
