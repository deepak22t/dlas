from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from langchain_core.messages import AnyMessage


class GraphState(TypedDict):
    task_id: str
    messages: Annotated[list[AnyMessage], add_messages]